/**
 * 
 */
package com.signify.exception;

/**
 * @author GROUP H
 *
 */
public class NoCourseException extends Exception {

	/**
	 * 
	 */
	public NoCourseException() {
		// TODO Auto-generated constructor stub
		super();
		//Message returned when com.signify.exception is thrown
		 
		System.out.println("There are no courses available yet. ");
	}
	//Message returned when com.signify.exception is thrown

}
