package com.signify.exception;

public class InvalidEntryException extends Exception{

	public InvalidEntryException() {
		// TODO Auto-generated constructor stub

		/**
		 * com.signify.exception for invalid entry
		 */
		System.out.println(" Please enter a valid numeric input. ");
	}

}

