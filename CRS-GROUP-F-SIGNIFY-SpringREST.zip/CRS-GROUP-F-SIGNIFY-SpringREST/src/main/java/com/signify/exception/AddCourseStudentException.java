package com.signify.exception;

public class AddCourseStudentException extends Exception{

	public AddCourseStudentException(String message) {
		// TODO Auto-generated constructor stub
		System.out.println(message);
		//Message returned when com.signify.exception is thrown
		 
	}

}
