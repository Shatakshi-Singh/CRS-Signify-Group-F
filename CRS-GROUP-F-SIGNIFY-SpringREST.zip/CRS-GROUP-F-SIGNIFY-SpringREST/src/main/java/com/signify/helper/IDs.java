/**
 * 
 */
package com.signify.helper;

/**
 * @author GROUP-H-CRS-SIGNIFY
 *
 */
public class IDs {
		/**
			method to store connection and database credentials 
		
		
		**/
	 public static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";  
	   public static final String DB_URL = "jdbc:mysql://localhost/databasecrs";
		
	  //  Database credentials
	   public static final String USER = "root";
	   public static final String PASS = "123456";
	   
}
